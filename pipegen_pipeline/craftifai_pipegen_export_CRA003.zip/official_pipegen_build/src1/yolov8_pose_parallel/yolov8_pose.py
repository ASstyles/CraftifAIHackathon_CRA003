#!/usr/bin/env python3
"""YOLOv8 person detection + YOLO11-pose estimation on NVIDIA TensorRT / PipeGen.

Runs the parallel detection and pose inference pipeline on NVIDIA GPU:
1. Native TensorRT 10.3 Engine execution with explicit CUDA host/device transfers (cudaMemcpy H2D/D2H).
2. Greedy IoU-based object tracker (associates detections across frames, subject to identity switches during occlusions).
3. Pose-Driven Ground Contact Localization (uses ankle keypoints when confidence >= 0.30,
   with bounding-box bottom-center fallback).
4. Direct REST webhook ingestion into SentinelVision FastAPI backend (/api/pipegen/ingest).
   Note: Delivery confirms HTTP receipt of frame metadata; incident generation requires zone boundary breach.

Usage:
    python yolov8_pose.py --input video.mp4 --output out.mp4 --api-ingest http://localhost:8000/api/pipegen/ingest
"""

import argparse
import os
import sys
import time
import json
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import cv2
import numpy as np

from detectors import (
    create_yolo_detector,
    create_pose_estimator,
    open_source
)

HERE = os.path.dirname(os.path.abspath(__file__))


# ===========================================================================
# Persistent Spatial IoU Object Tracker
# ===========================================================================
class Track:
    def __init__(self, track_id: int, box, score: float, class_id: int = 0):
        self.track_id = track_id
        self.box = np.array(box, dtype=np.float32)  # [x1, y1, x2, y2]
        self.score = float(score)
        self.class_id = int(class_id)
        self.hits = 1
        self.time_since_update = 0

    def update(self, box, score: float):
        # Smooth box coordinates using EMA
        self.box = 0.7 * np.array(box, dtype=np.float32) + 0.3 * self.box
        self.score = float(score)
        self.hits += 1
        self.time_since_update = 0


class SpatialTracker:
    """Spatial object tracker using greedy bounding-box IoU association (subject to identity switches during occlusion/overlap)."""
    def __init__(self, max_age: int = 20, iou_threshold: float = 0.3):
        self.max_age = max_age
        self.iou_threshold = iou_threshold
        self.tracks = []
        self.next_id = 1

    @staticmethod
    def _compute_iou(boxA, boxB):
        xA = max(boxA[0], boxB[0])
        yA = max(boxA[1], boxB[1])
        xB = min(boxA[2], boxB[2])
        yB = min(boxA[3], boxB[3])
        inter = max(0.0, xB - xA) * max(0.0, yB - yA)
        areaA = max(1.0, (boxA[2] - boxA[0]) * (boxA[3] - boxA[1]))
        areaB = max(1.0, (boxB[2] - boxB[0]) * (boxB[3] - boxB[1]))
        return inter / (areaA + areaB - inter)

    def update(self, raw_detections):
        """
        raw_detections: list of (box, score, class_id)
        returns: list of Track objects
        """
        # Age existing tracks
        for t in self.tracks:
            t.time_since_update += 1

        if len(raw_detections) == 0:
            self.tracks = [t for t in self.tracks if t.time_since_update <= self.max_age]
            return []

        # IoU matching matrix
        matched_tracks = set()
        matched_dets = set()

        if self.tracks:
            iou_matrix = np.zeros((len(self.tracks), len(raw_detections)), dtype=np.float32)
            for i, trk in enumerate(self.tracks):
                for j, (box, _, _) in enumerate(raw_detections):
                    iou_matrix[i, j] = self._compute_iou(trk.box, box)

            # Greedy matching by highest IoU
            while True:
                max_val = np.max(iou_matrix)
                if max_val < self.iou_threshold:
                    break
                i, j = np.unravel_index(np.argmax(iou_matrix), iou_matrix.shape)
                if i not in matched_tracks and j not in matched_dets:
                    self.tracks[i].update(raw_detections[j][0], raw_detections[j][1])
                    matched_tracks.add(i)
                    matched_dets.add(j)
                iou_matrix[i, :] = -1
                iou_matrix[:, j] = -1

        # Spawn new tracks for unmatched detections
        for j, (box, score, cid) in enumerate(raw_detections):
            if j not in matched_dets:
                new_track = Track(self.next_id, box, score, cid)
                self.next_id += 1
                self.tracks.append(new_track)

        # Retire dead tracks
        self.tracks = [t for t in self.tracks if t.time_since_update <= self.max_age]

        # Return tracks that were updated this frame
        return [t for t in self.tracks if t.time_since_update == 0]


def compute_ground_contact(box, pose_res, iou_thresh=0.35, ankle_conf_thresh=0.3):
    """
    Associate a person bounding box with pose estimation keypoints to determine
    ground contact point (ankles projection or bounding box bottom-center fallback).
    """
    x1, y1, x2, y2 = [float(v) for v in box]
    contact_x = (x1 + x2) / 2.0
    contact_y = y2
    contact_source = "bbox_bottom_center"

    for p_det in pose_res:
        p_box = p_det.get("box", [0, 0, 0, 0])
        ix1, iy1 = max(x1, p_box[0]), max(y1, p_box[1])
        ix2, iy2 = min(x2, p_box[2]), min(y2, p_box[3])
        inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
        if inter > 0:
            area_t = max(1.0, (x2 - x1) * (y2 - y1))
            area_p = max(1.0, (p_box[2] - p_box[0]) * (p_box[3] - p_box[1]))
            p_iou = inter / (area_t + area_p - inter)
            if p_iou >= iou_thresh:
                kx = p_det.get("kx", [])
                ky = p_det.get("ky", [])
                kc = p_det.get("kc", [])
                left_visible = (len(kc) > 15 and kc[15] >= ankle_conf_thresh)
                right_visible = (len(kc) > 16 and kc[16] >= ankle_conf_thresh)
                if left_visible and right_visible:
                    contact_x = float((kx[15] + kx[16]) / 2.0)
                    contact_y = float(max(ky[15], ky[16]))
                    contact_source = "pose_ankles"
                elif left_visible:
                    contact_x = float(kx[15])
                    contact_y = float(ky[15])
                    contact_source = "pose_left_ankle"
                elif right_visible:
                    contact_x = float(kx[16])
                    contact_y = float(ky[16])
                    contact_source = "pose_right_ankle"
                break

    return [contact_x, contact_y], contact_source


# ===========================================================================
# CLI Arguments
# ===========================================================================
def parse_args():
    p = argparse.ArgumentParser(description="SentinelVision YOLOv8 + Pose Parallel Pipeline")
    p.add_argument("--input", default="0", help="video path or webcam index")
    p.add_argument("--yolo-model", default=os.path.join(HERE, "models", "yolov8n.onnx"),
                   help="path to yolov8n.onnx or yolov8n.fp32.plan")
    p.add_argument("--pose-model", default=os.path.join(HERE, "models", "yolo11n-pose.onnx"),
                   help="path to yolo11n-pose.onnx or yolo11n-pose.fp32.plan")
    p.add_argument("--conf", type=float, default=0.4, help="YOLOv8 person confidence")
    p.add_argument("--pose-conf", type=float, default=0.25, help="pose person confidence")
    p.add_argument("--output", default=None, help="write annotated video here")
    p.add_argument("--runtime", default="tensorrt_required",
                   choices=["tensorrt_required", "onnx_cuda_allowed", "onnx_cpu_allowed"],
                   help="runtime backend requirement: tensorrt_required, onnx_cuda_allowed, or onnx_cpu_allowed")
    p.add_argument("--no-show", action="store_true", help="disable display window")
    p.add_argument("--api-ingest", default=None,
                   help="URL to post frame detections to (e.g. http://localhost:8000/api/pipegen/ingest)")
    p.add_argument("--loop", action="store_true", help="loop video continuously")
    return p.parse_args()


# ===========================================================================
# Main Execution Pipeline
# ===========================================================================
def main():
    args = parse_args()

    print("=== SentinelVision PipeGen Inference Runner (DeepStream Container Environment) ===")
    print(f"  Target Video Source : {args.input}")
    print(f"  YOLOv8 Model Target : {args.yolo_model}")
    print(f"  Pose Model Target   : {args.pose_model}")
    print(f"  Runtime Mode Policy : {args.runtime}")

    # Initialize detectors with strict runtime policy
    yolo = create_yolo_detector(args.yolo_model, conf=args.conf, runtime_mode=args.runtime)
    pose = create_pose_estimator(args.pose_model, conf=args.pose_conf, runtime_mode=args.runtime)

    # Initialize persistent spatial tracker
    tracker = SpatialTracker(max_age=15, iou_threshold=0.3)

    cap = open_source(args.input)
    if not cap.isOpened():
        sys.exit(f"Could not open video input: {args.input}")

    writer = None
    if args.output:
        fps_val = cap.get(cv2.CAP_PROP_FPS) or 30.0
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        writer = cv2.VideoWriter(args.output, cv2.VideoWriter_fourcc(*"mp4v"), fps_val, (w, h))

    win = "SentinelVision PipeGen GPU Stream"
    if not args.no_show:
        cv2.namedWindow(win, cv2.WINDOW_NORMAL)

    pool = ThreadPoolExecutor(max_workers=2)
    fps = 0.0
    frame_idx = 0
    ingest_sent_count = 0
    ingest_fail_count = 0
    last_ingest_error = None

    active_api_ingest = args.api_ingest
    if active_api_ingest and ("localhost" in active_api_ingest or "127.0.0.1" in active_api_ingest):
        # Test if localhost is directly reachable; if not, discover WSL/Docker host gateway
        try:
            urllib.request.urlopen(active_api_ingest, timeout=0.3)
        except urllib.error.HTTPError:
            pass  # HTTP error (e.g. 405 Method Not Allowed) means endpoint is reachable
        except Exception:
            candidates = []
            # Check default route or resolv.conf
            try:
                with open("/proc/net/route", "r") as f:
                    for line in f:
                        fields = line.strip().split()
                        if len(fields) >= 3 and fields[1] == "00000000":
                            gw_hex = fields[2]
                            gw_ip = ".".join(str(int(gw_hex[i:i+2], 16)) for i in (6, 4, 2, 0))
                            candidates.append(gw_ip)
            except Exception:
                pass
            try:
                with open("/etc/resolv.conf", "r") as f:
                    for line in f:
                        if line.startswith("nameserver"):
                            candidates.append(line.split()[1].strip())
            except Exception:
                pass
            candidates.extend(["172.18.32.1", "172.17.0.1", "172.19.0.1", "host.docker.internal"])
            for cand in candidates:
                cand_url = active_api_ingest.replace("localhost", cand).replace("127.0.0.1", cand)
                try:
                    urllib.request.urlopen(cand_url, timeout=0.3)
                    print(f"[Ingest Discovery] Resolved host gateway ingestion URL: {cand_url}")
                    active_api_ingest = cand_url
                    break
                except urllib.error.HTTPError:
                    print(f"[Ingest Discovery] Resolved host gateway ingestion URL: {cand_url}")
                    active_api_ingest = cand_url
                    break
                except Exception:
                    continue

    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                if args.loop:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    continue
                break

            t0 = time.time()

            # Execute dual models in parallel with precise inference timing
            t_infer_start = time.perf_counter()
            f_yolo = pool.submit(yolo.infer, frame)
            f_pose = pool.submit(pose.infer, frame)
            yolo_res, pose_res = f_yolo.result(), f_pose.result()
            infer_ms = (time.perf_counter() - t_infer_start) * 1000.0

            # Filter persons (class_id 0) and update persistent tracker
            person_dets = [d for d in yolo_res if d[2] == 0]
            active_tracks = tracker.update(person_dets)

            # Ingest detections to SentinelVision backend with Pose-Driven Foot Localization
            if active_api_ingest:
                objects = []
                for trk in active_tracks:
                    x1, y1, x2, y2 = [float(v) for v in trk.box]
                    
                    # Pose Association: Find corresponding pose keypoints by IoU
                    contact_pt, contact_source = compute_ground_contact([x1, y1, x2, y2], pose_res)
                    contact_x, contact_y = contact_pt

                    objects.append({
                        "class_id": 0,
                        "obj_label": "person",
                        "confidence": round(float(trk.score), 3),
                        "object_id": trk.track_id,  # Greedy IoU track ID (subject to identity switches)
                        "rect_params": {
                            "left": round(x1, 1),
                            "top": round(y1, 1),
                            "width": max(1.0, round(x2 - x1, 1)),
                            "height": max(1.0, round(y2 - y1, 1))
                        },
                        "detection_point": [round(contact_x, 1), round(contact_y, 1)],
                        "contact_source": contact_source
                    })

                try:
                    payload = json.dumps({
                        "frame_num": frame_idx,
                        "source_id": 0,
                        "objects": objects,
                        "inference_backend": getattr(yolo, "backend_name", "Unknown"),
                        "inference_latency_ms": round(infer_ms, 2)
                    }).encode("utf-8")
                    req = urllib.request.Request(
                        active_api_ingest,
                        data=payload,
                        headers={"Content-Type": "application/json"}
                    )
                    with urllib.request.urlopen(req, timeout=0.5) as resp:
                        if resp.status == 200:
                            ingest_sent_count += 1
                        else:
                            ingest_fail_count += 1
                            if ingest_fail_count <= 3 or ingest_fail_count % 60 == 0:
                                print(f"[Ingest Warning] HTTP {resp.status} posting frame {frame_idx} to {active_api_ingest}", file=sys.stderr)
                except urllib.error.URLError as e:
                    ingest_fail_count += 1
                    last_ingest_error = str(e.reason) if hasattr(e, "reason") else str(e)
                    if ingest_fail_count <= 3 or ingest_fail_count % 60 == 0:
                        print(f"[Ingest Connection Error] Frame {frame_idx} failed: {last_ingest_error}", file=sys.stderr)
                except Exception as e:
                    ingest_fail_count += 1
                    last_ingest_error = str(e)
                    if ingest_fail_count <= 3 or ingest_fail_count % 60 == 0:
                        print(f"[Ingest Error] Frame {frame_idx} failed: {e}", file=sys.stderr)

            frame_idx += 1

            # Draw visual feedback
            yolo.draw(frame, person_dets)
            pose.draw(frame, pose_res)

            # Draw persistent track IDs and foot contact points
            for trk in active_tracks:
                bx1, by1, bx2, by2 = [int(v) for v in trk.box]
                cv2.putText(frame, f"ID: {trk.track_id}", (bx1, by1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2, cv2.LINE_AA)

            fps = 0.9 * fps + 0.1 * (1.0 / max(time.time() - t0, 1e-6))
            cv2.putText(frame, f"{fps:4.1f} FPS (PipeGen)",
                        (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2, cv2.LINE_AA)

            if writer:
                writer.write(frame)
            if not args.no_show:
                cv2.imshow(win, frame)
                if (cv2.waitKey(1) & 0xFF) in (ord("q"), 27):
                    break
    finally:
        pool.shutdown(wait=False)
        cap.release()
        if writer:
            writer.release()
        if not args.no_show:
            cv2.destroyAllWindows()
        if hasattr(yolo, "close"):
            try:
                yolo.close()
            except Exception:
                pass
        if hasattr(pose, "close"):
            try:
                pose.close()
            except Exception:
                pass
        print(f"Pipeline execution finished. Processed {frame_idx} frames.")
        if active_api_ingest:
            print(f"Backend Ingest Telemetry: {ingest_sent_count} delivered, {ingest_fail_count} failed to {active_api_ingest} (HTTP ingestion delivers frame metadata; incidents require zone boundary intrusion)")


if __name__ == "__main__":
    main()
